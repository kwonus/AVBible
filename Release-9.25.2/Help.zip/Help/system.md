
See "S4T Grammar" for detailed usage information of the Search-for-Truth (S4T) Grammar, and various parameters for each command.

### Macros & Search History

*@history*

*@macros*

*@view* tag

*@use* tag

*@delete* tag

### Configuration Settings

*@get* configuration

*@set* configuration

*@clear* configuration

### Exiting the Application

An alternate way to terminate the application:

*@exit*
